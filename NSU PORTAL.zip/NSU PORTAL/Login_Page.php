<?php
session_start();
$connect = mysqli_connect("localhost", "root", "", "nsu_portal");
?>

<!DOCTYPE html PUBLIC "-//w3c//DTD XHTML 1.0 Transtional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html>
    <head>            
        <title> 
            Login Page
        </title>

        <link rel="stylesheet" type ="text/css" href="Css files/Login_Page.css">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />		
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
         <style>
		 .fb {
  background-color: #3B5998;
  color: white;
}

.twitter {
  background-color: #55ACEE;
  color: white;
}

.google {
  background-color: #dd4b39;
  color: white;
}

* {
  box-sizing: border-box;
}

body {
  font-family: Arial;
  font-size: 17px;
}

.container {
  position: relative;
  max-width: 800px;
  margin: 0 auto;
}

.container img {vertical-align: middle;}

.container .content {
  position: absolute;
  bottom: 0;
  background: rgb(0, 0, 0); /* Fallback color */
  background: rgba(0, 0, 0, 0.5); /* Black background with 0.5 opacity */
  color: #f1f1f1;
  width: 100%;
  padding: 20px;
}
</style>
		 
    </head>

    <body background="pictures/c.jpg" style="color:white;">
        <div class="main_container">	 
            <div class="navigation-bar">
                <input type= "image" id= "logo" src="pictures/A.png" />
                <h3 id="hh">NORTH SOUTH UNIVERSITY</h3> <br>
                <h5 id="hh1">Center of Excellence in Higher Education</h5>
                <h6 id="hh2">The first private university of Bangladesh</h6>
            </div>
			
			<h1 align="center">University Management System</h1>

            <div id= "User_Pass">			
                <center>
                    <form class="myform" action="Login_page.php"  method="post">
                        <input type= "text" id= "id" name="id" placeholder=" Enter Username " /> <br><br> 							
                        <input type= "Password" id="pass" name="Password" placeholder="Enter Password" /><br>		    
                        <a href="pictures/F.jpg" title="Forgot Password" > Forgot password ?</a> <br><br><br>						    						
                        <input type="submit" name="L_button" id="L_button" value="Login"> </input> <br><br>
                    </form>	
                </center>
            </div> <!-- Username,password box ends here-->
			

			
			<div class="col">
        <a href="http://localhost/NSU%20PORTAL/Home.php" class="fb btn">
          <i class="fa fa-facebook fa-fw"></i> Login with Facebook
         </a>
        <a href="http://localhost/NSU%20PORTAL/Home.php" class="twitter btn">
          <i class="fa fa-twitter fa-fw"></i> Login with Twitter
        </a>
        <a href="http://localhost/NSU%20PORTAL/Home.php" class="google btn"><i class="fa fa-google fa-fw">
          </i> Login with Google+
        </a>
      </div>


            <?php
            if (isset($_POST['L_button'])) 
			{
            
						if ($_POST["id"] == 'admin' && $_POST['Password'] == admin)
						{
                            header('location:Home.php');
                        }
						else 
						{ // this 'else' using for both students and faculties invalid login 
                            echo '<script type="text/javascript"> alert("Username or Password is incorrect") </script>';
                        }
                    }
        
            ?>

        </div>

    </body>
</html>	
