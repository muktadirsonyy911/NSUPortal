

<!DOCTYPE html>

<html>
    <head>            
        <title> T_Dashboard </title>	
		<link rel="stylesheet" type ="text/css" href="Home.css">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />	
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>	
		
    </head>

    <body>
     	<div class="navigation-bar">
            <input type= "image" id= "logo" src="pictures/A.png" />
            <h3 id="hh">NORTH SOUTH UNIVERSITY</h3> <br>
            <h5 id="hh1">Center of Excellence in Higher Education</h5>
            <h6 id="hh2">The first private university of Bangladesh</h6>
		</div>         <br><br><br><br><br><br>

        <a href="http://localhost/NSU%20PORTAL/Teacher Portal.php"> <input type= "image" id= "Login_Button" src="pictures/log.jpg" /> </a>
        <div class="navigation">		  
            <ul> 
				<li> <a href="http://localhost/NSU%20PORTAL/Home.php"> <i class="fas fa-home"></i> Home </a> </li>
				<li> <a href="http://localhost/NSU%20PORTAL/Teachers information.php" target="_blank"><i class="fas fa-user-alt"></i> Profile</a> </li>
				<li> <a href="http://localhost/NSU%20PORTAL/Teach.php "> <i class="far fa-edit" target="_blank"></i> Courses </a> </li>	
				<li> <a href="http://localhost/NSU%20PORTAL/t_advising.php"><i class="far fa-edit" target="_blank"></i> Advising </a> </li>	
			</ul>
		</div>				
</body>
</html>		



