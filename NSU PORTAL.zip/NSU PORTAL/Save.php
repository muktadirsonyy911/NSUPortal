<?php 
    session_start();
	$connect = mysqli_connect('localhost','root','','nsu_portal');

	if($_REQUEST["Courses"] || $_REQUEST["Section"] || $_REQUEST["Credit" || $_REQUEST["Time"] ){

	
	    $id= $_SESSION["id"];
		$course = json_decode(stripslashes($_POST['Courses']));
		$section = json_decode(stripslashes($_POST['Section']));
		$credit = json_decode(stripslashes($_POST['Credit']));
		$fees = json_decode(stripslashes($_POST['Time']));
		$length = count($Courses);
		for($x = 0; $x < $length; $x++) 
		{
		    $q = "insert into taken_courses values('$Courses[$x]','$Section[$x]','$Credit[$x]','$Time[$x]')";
		    $query = mysqli_query($connect,$q);
		}
	
			
	}
?>
			