<?php 
    session_start();
	$connect = mysqli_connect('localhost','root','','nsu_portal');
	
	 $id= $_SESSION["id"];
	 echo $id;

	if($_REQUEST["courses"] || $_REQUEST["section"] || $_REQUEST["credit"] || $_REQUEST["Fees"] ){

	
	    $id= $_SESSION["id"];
	
		$courses = json_decode(stripslashes($_POST['courses']));
		$section = json_decode(stripslashes($_POST['section']));
		$credit = json_decode(stripslashes($_POST['credit']));
		$Fees = json_decode(stripslashes($_POST['Fees']));
		$length = count($courses);
		for($x = 0; $x < $length; $x++) 
		{
		    $q = "delete from taken_courses where Courses='ENG103'";
		    $query = mysqli_query($connect,$q);
		}
	
			
	}
?>
			